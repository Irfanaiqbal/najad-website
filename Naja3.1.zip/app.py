from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import sqlite3

app = Flask(__name__)

# Use environment variable for secret key in production
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-secret-key-here-change-in-production')

# Database configuration
if 'RENDER' in os.environ:
    # On Render, use the provided database URL or SQLite as fallback
    database_url = os.environ.get('DATABASE_URL')
    if database_url:
        if database_url.startswith('postgres://'):
            database_url = database_url.replace('postgres://', 'postgresql://', 1)
        app.config['SQLALCHEMY_DATABASE_URI'] = database_url
    else:
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///dropship.db'
else:
    # Local development
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///dropship.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    addresses = db.relationship('Address', backref='user', lazy=True)
    orders = db.relationship('Order', backref='user', lazy=True)

class Address(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    street = db.Column(db.String(200), nullable=False)
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100), nullable=False)
    zip_code = db.Column(db.String(20), nullable=False)
    country = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    is_primary = db.Column(db.Boolean, default=False)

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    products = db.relationship('Product', backref='category', lazy=True)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    original_price = db.Column(db.Float, nullable=True)
    cost_price = db.Column(db.Float, nullable=False, default=0.0)
    stock = db.Column(db.Integer, nullable=False)
    image_url = db.Column(db.String(300), default='https://via.placeholder.com/300x300?text=Product')
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    sku = db.Column(db.String(100), default='')
    is_on_sale = db.Column(db.Boolean, default=False)
    sale_percentage = db.Column(db.Float, default=0.0)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), default='Pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    shipping_address = db.Column(db.Text, nullable=False)
    customer_phone = db.Column(db.String(20))
    customer_email = db.Column(db.String(120))
    customer_name = db.Column(db.String(150))
    order_items = db.relationship('OrderItem', backref='order', lazy=True)

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    product = db.relationship('Product', backref='order_items')

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    product = db.relationship('Product', backref='cart_items')

# Helper functions
def init_categories():
    categories = ['Clothing', 'Shoes', 'Gadgets', 'Accessories']
    for cat_name in categories:
        if not Category.query.filter_by(name=cat_name).first():
            category = Category(name=cat_name)
            db.session.add(category)
    db.session.commit()

def init_sample_products():
    # Check if we have any products at all
    try:
        product_count = Product.query.count()
    except Exception as e:
        print(f"Error counting products: {e}")
        # If there's an error, assume we need to recreate the database
        db.drop_all()
        db.create_all()
        init_categories()
        product_count = 0

    if product_count == 0:
        sample_products = [
            {'name': 'Premium T-Shirt', 'description': 'High-quality cotton t-shirt', 'price': 1999.00, 'original_price': 2499.00, 'cost_price': 1200.00, 'stock': 50, 'category_id': 1, 'sku': 'TSHIRT001', 'image_url': 'https://via.placeholder.com/300x300?text=T-Shirt', 'is_on_sale': True, 'sale_percentage': 20},
            {'name': 'Running Shoes', 'description': 'Comfortable running shoes', 'price': 4599.00, 'original_price': 5999.00, 'cost_price': 2800.00, 'stock': 30, 'category_id': 2, 'sku': 'SHOES001', 'image_url': 'https://via.placeholder.com/300x300?text=Shoes', 'is_on_sale': True, 'sale_percentage': 23},
            {'name': 'Smart Watch', 'description': 'Feature-rich smartwatch', 'price': 12999.00, 'original_price': 15999.00, 'cost_price': 8500.00, 'stock': 20, 'category_id': 3, 'sku': 'WATCH001', 'image_url': 'https://via.placeholder.com/300x300?text=Watch', 'is_on_sale': True, 'sale_percentage': 19},
            {'name': 'Wireless Earbuds', 'description': 'Noise cancelling earbuds', 'price': 7999.00, 'cost_price': 4800.00, 'stock': 25, 'category_id': 3, 'sku': 'EARBUDS001', 'image_url': 'https://via.placeholder.com/300x300?text=Earbuds', 'is_on_sale': False, 'sale_percentage': 0},
            {'name': 'Designer Jeans', 'description': 'Premium denim jeans', 'price': 3499.00, 'original_price': 4499.00, 'cost_price': 2200.00, 'stock': 40, 'category_id': 1, 'sku': 'JEANS001', 'image_url': 'https://via.placeholder.com/300x300?text=Jeans', 'is_on_sale': True, 'sale_percentage': 22},
            {'name': 'Leather Wallet', 'description': 'Genuine leather wallet', 'price': 2499.00, 'cost_price': 1500.00, 'stock': 15, 'category_id': 4, 'sku': 'WALLET001', 'image_url': 'https://via.placeholder.com/300x300?text=Wallet', 'is_on_sale': False, 'sale_percentage': 0},
        ]
        
        for product_data in sample_products:
            product = Product(**product_data)
            db.session.add(product)
        db.session.commit()
        print("✅ Sample products created!")

def migrate_database():
    """Check and update database schema if needed"""
    try:
        # Try to access the new columns
        test_product = Product.query.first()
        if test_product:
            # If we can access a product, check if new columns exist
            try:
                _ = test_product.cost_price
                _ = test_product.sku
                _ = test_product.original_price
                _ = test_product.is_on_sale
                _ = test_product.sale_percentage
                print("✅ Database schema is up to date")
                return True
            except AttributeError:
                print("🔄 Database schema needs update...")
    except Exception as e:
        print(f"Database error: {e}")
    
    # If we get here, we need to recreate the database
    print("🔄 Recreating database with new schema...")
    db.drop_all()
    db.create_all()
    return False

def get_low_stock_products():
    return Product.query.filter(Product.stock < 10, Product.stock > 0).all()

def get_out_of_stock_products():
    return Product.query.filter(Product.stock == 0).all()

def get_recent_orders(limit=5):
    return Order.query.order_by(Order.created_at.desc()).limit(limit).all()

def get_total_revenue():
    return db.session.query(db.func.sum(Order.total_amount)).filter(Order.status.in_(['Delivered', 'Shipped'])).scalar() or 0

def get_total_profit():
    delivered_orders = Order.query.filter(Order.status.in_(['Delivered', 'Shipped'])).all()
    total_profit = 0
    for order in delivered_orders:
        for item in order.order_items:
            product = Product.query.get(item.product_id)
            if product:
                total_profit += (item.price - product.cost_price) * item.quantity
    return total_profit

# Calculate discount percentage
def calculate_discount_percentage(original_price, current_price):
    if original_price and original_price > current_price:
        return int(((original_price - current_price) / original_price) * 100)
    return 0

# Safe float conversion function
def safe_float_convert(value, default=0.0):
    """Safely convert string to float, return default if conversion fails"""
    if not value:
        return default
    try:
        return float(value)
    except (ValueError, TypeError):
        return default

# Format currency in INR
def format_currency(amount):
    """Format amount as Indian Rupees"""
    if amount is None:
        return "₹0"
    return f"₹{amount:,.2f}"

# Routes
@app.route('/')
def index():
    products = Product.query.filter_by(is_active=True).limit(8).all()
    # Calculate discount percentages for products
    for product in products:
        product.discount_percentage = calculate_discount_percentage(product.original_price, product.price)
    return render_template('index.html', products=products, format_currency=format_currency)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        phone = request.form.get('phone', '')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered!', 'error')
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password)
        user = User(email=email, password=hashed_password, first_name=first_name, last_name=last_name, phone=phone)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['user_email'] = user.email
            session['user_name'] = f"{user.first_name} {user.last_name}"
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password!', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    addresses = Address.query.filter_by(user_id=user.id).all()
    return render_template('profile.html', user=user, addresses=addresses)

@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    user.first_name = request.form['first_name']
    user.last_name = request.form['last_name']
    user.phone = request.form.get('phone', '')
    db.session.commit()
    
    session['user_name'] = f"{user.first_name} {user.last_name}"
    flash('Profile updated successfully!', 'success')
    return redirect(url_for('profile'))

@app.route('/change_password', methods=['POST'])
def change_password():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    current_password = request.form['current_password']
    new_password = request.form['new_password']
    
    if check_password_hash(user.password, current_password):
        user.password = generate_password_hash(new_password)
        db.session.commit()
        flash('Password changed successfully!', 'success')
    else:
        flash('Current password is incorrect!', 'error')
    
    return redirect(url_for('profile'))

@app.route('/add_address', methods=['POST'])
def add_address():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    address = Address(
        user_id=session['user_id'],
        street=request.form['street'],
        city=request.form['city'],
        state=request.form['state'],
        zip_code=request.form['zip_code'],
        country=request.form['country'],
        phone=request.form.get('phone', '')
    )
    
    db.session.add(address)
    db.session.commit()
    flash('Address added successfully!', 'success')
    return redirect(url_for('profile'))

@app.route('/products')
def products():
    category_id = request.args.get('category_id', type=int)
    search = request.args.get('search', '')
    
    query = Product.query.filter_by(is_active=True)
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    if search:
        query = query.filter(Product.name.contains(search) | Product.description.contains(search))
    
    products = query.all()
    # Calculate discount percentages for products
    for product in products:
        product.discount_percentage = calculate_discount_percentage(product.original_price, product.price)
    
    categories = Category.query.all()
    return render_template('products.html', products=products, categories=categories, format_currency=format_currency)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    product.discount_percentage = calculate_discount_percentage(product.original_price, product.price)
    return render_template('product_detail.html', product=product, format_currency=format_currency)

@app.route('/add_to_cart/<int:product_id>')
def add_to_cart(product_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    product = Product.query.get_or_404(product_id)
    
    if product.stock <= 0:
        flash('Sorry, this product is out of stock!', 'error')
        return redirect(request.referrer or url_for('index'))
    
    cart_item = Cart.query.filter_by(user_id=session['user_id'], product_id=product_id).first()
    
    if cart_item:
        if cart_item.quantity + 1 > product.stock:
            flash('Cannot add more than available stock!', 'error')
        else:
            cart_item.quantity += 1
            db.session.commit()
            flash('Product added to cart!', 'success')
    else:
        cart_item = Cart(user_id=session['user_id'], product_id=product_id, quantity=1)
        db.session.add(cart_item)
        db.session.commit()
        flash('Product added to cart!', 'success')
    
    return redirect(request.referrer or url_for('index'))

@app.route('/cart')
def cart():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cart_items = Cart.query.filter_by(user_id=session['user_id']).all()
    
    # Calculate discount percentages for products in cart
    for item in cart_items:
        # Calculate discount percentage on the fly
        if item.product.original_price and item.product.original_price > item.product.price:
            item.product.discount_percentage = int(((item.product.original_price - item.product.price) / item.product.original_price * 100))
        else:
            item.product.discount_percentage = 0
    
    total = sum(item.product.price * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total, format_currency=format_currency)

@app.route('/update_cart/<int:cart_id>', methods=['POST'])
def update_cart(cart_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    cart_item = Cart.query.get_or_404(cart_id)
    if cart_item.user_id != session['user_id']:
        return redirect(url_for('cart'))
    
    new_quantity = int(request.form['quantity'])
    if new_quantity <= 0:
        db.session.delete(cart_item)
    elif new_quantity > cart_item.product.stock:
        flash('Cannot add more than available stock!', 'error')
    else:
        cart_item.quantity = new_quantity
    
    db.session.commit()
    return redirect(url_for('cart'))

@app.route('/remove_from_cart/<int:cart_id>')
def remove_from_cart(cart_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    cart_item = Cart.query.get_or_404(cart_id)
    if cart_item.user_id != session['user_id']:
        return redirect(url_for('cart'))
    
    db.session.delete(cart_item)
    db.session.commit()
    flash('Item removed from cart!', 'success')
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    cart_items = Cart.query.filter_by(user_id=session['user_id']).all()
    addresses = Address.query.filter_by(user_id=session['user_id']).all()
    
    if not cart_items:
        flash('Your cart is empty!', 'error')
        return redirect(url_for('cart'))
    
    # Check stock availability
    for item in cart_items:
        if item.quantity > item.product.stock:
            flash(f'Not enough stock for {item.product.name}! Only {item.product.stock} available.', 'error')
            return redirect(url_for('cart'))
    
    if request.method == 'POST':
        address_id = request.form['address_id']
        address = Address.query.get(address_id)
        
        if not address:
            flash('Please select a valid address!', 'error')
            return redirect(url_for('checkout'))
        
        # Create order
        total = sum(item.product.price * item.quantity for item in cart_items)
        shipping_address = f"{address.street}, {address.city}, {address.state} {address.zip_code}, {address.country}"
        
        order = Order(
            user_id=session['user_id'],
            total_amount=total,
            shipping_address=shipping_address,
            customer_phone=request.form.get('phone', address.phone or user.phone),
            customer_email=user.email,
            customer_name=f"{user.first_name} {user.last_name}"
        )
        db.session.add(order)
        db.session.flush()  # Get the order ID
        
        # Create order items and update stock
        for cart_item in cart_items:
            order_item = OrderItem(
                order_id=order.id,
                product_id=cart_item.product_id,
                quantity=cart_item.quantity,
                price=cart_item.product.price
            )
            db.session.add(order_item)
            
            # Update stock
            product = cart_item.product
            product.stock -= cart_item.quantity
        
        # Clear cart
        Cart.query.filter_by(user_id=session['user_id']).delete()
        db.session.commit()
        
        flash('Order placed successfully!', 'success')
        return redirect(url_for('order_confirmation', order_id=order.id))
    
    total = sum(item.product.price * item.quantity for item in cart_items)
    return render_template('checkout.html', cart_items=cart_items, total=total, addresses=addresses, user=user, format_currency=format_currency)

@app.route('/order_confirmation/<int:order_id>')
def order_confirmation(order_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    order = Order.query.get_or_404(order_id)
    if order.user_id != session['user_id'] and session.get('user_email') != 'admin@dropship.com':
        return redirect(url_for('index'))
        
    return render_template('order_confirmation.html', order=order, format_currency=format_currency)

@app.route('/orders')
def orders():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_orders = Order.query.filter_by(user_id=session['user_id']).order_by(Order.created_at.desc()).all()
    return render_template('orders.html', orders=user_orders, format_currency=format_currency)

@app.route('/order_details/<int:order_id>')
def order_details(order_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    order = Order.query.get_or_404(order_id)
    if order.user_id != session['user_id'] and session.get('user_email') != 'admin@dropship.com':
        return redirect(url_for('index'))
        
    return render_template('order_details.html', order=order, format_currency=format_currency)

# Admin Routes
@app.route('/admin')
def admin_dashboard():
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    total_products = Product.query.count()
    total_orders = Order.query.count()
    total_users = User.query.count()
    low_stock_products = get_low_stock_products()
    out_of_stock_products = get_out_of_stock_products()
    recent_orders = get_recent_orders(5)
    total_revenue = get_total_revenue()
    total_profit = get_total_profit()
    
    return render_template('admin/dashboard.html',
                         total_products=total_products,
                         total_orders=total_orders,
                         total_users=total_users,
                         low_stock_products=low_stock_products,
                         out_of_stock_products=out_of_stock_products,
                         recent_orders=recent_orders,
                         total_revenue=total_revenue,
                         total_profit=total_profit,
                         format_currency=format_currency)

@app.route('/admin/products')
def admin_products():
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    products = Product.query.all()
    categories = Category.query.all()
    return render_template('admin/products.html', products=products, categories=categories, format_currency=format_currency)

@app.route('/admin/add_product', methods=['POST'])
def admin_add_product():
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    try:
        is_on_sale = 'is_on_sale' in request.form
        original_price = safe_float_convert(request.form.get('original_price'), None)
        
        # Auto-calculate sale percentage if original price is provided
        sale_percentage = 0.0
        price = safe_float_convert(request.form['price'])
        if original_price and original_price > price:
            sale_percentage = ((original_price - price) / original_price) * 100
        
        product = Product(
            name=request.form['name'],
            description=request.form['description'],
            price=price,
            original_price=original_price,
            cost_price=safe_float_convert(request.form.get('cost_price', 0)),
            stock=int(request.form['stock']),
            category_id=int(request.form['category_id']),
            sku=request.form.get('sku', ''),
            image_url=request.form.get('image_url', 'https://via.placeholder.com/300x300?text=Product'),
            is_on_sale=is_on_sale,
            sale_percentage=sale_percentage
        )
        db.session.add(product)
        db.session.commit()
        flash('Product added successfully!', 'success')
    except Exception as e:
        flash(f'Error adding product: {str(e)}', 'error')
    
    return redirect(url_for('admin_products'))

@app.route('/admin/edit_product/<int:product_id>', methods=['GET', 'POST'])
def admin_edit_product(product_id):
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    product = Product.query.get_or_404(product_id)
    categories = Category.query.all()
    
    if request.method == 'POST':
        try:
            product.name = request.form['name']
            product.description = request.form['description']
            product.price = safe_float_convert(request.form['price'])
            
            # Handle original price safely
            original_price_str = request.form.get('original_price', '')
            if original_price_str.strip():
                product.original_price = safe_float_convert(original_price_str, None)
            else:
                product.original_price = None
            
            product.cost_price = safe_float_convert(request.form.get('cost_price', 0))
            product.stock = int(request.form['stock'])
            product.category_id = int(request.form['category_id'])
            product.sku = request.form.get('sku', '')
            product.image_url = request.form.get('image_url', product.image_url)
            product.is_active = 'is_active' in request.form
            product.is_on_sale = 'is_on_sale' in request.form
            
            # Auto-calculate sale percentage
            if product.original_price and product.original_price > product.price:
                product.sale_percentage = ((product.original_price - product.price) / product.original_price) * 100
            else:
                product.sale_percentage = 0.0
            
            db.session.commit()
            flash('Product updated successfully!', 'success')
            return redirect(url_for('admin_products'))
        except Exception as e:
            flash(f'Error updating product: {str(e)}', 'error')
    
    return render_template('admin/edit_product.html', product=product, categories=categories, format_currency=format_currency)

@app.route('/admin/delete_product/<int:product_id>')
def admin_delete_product(product_id):
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    product = Product.query.get_or_404(product_id)
    try:
        # Check if product is in any orders
        if product.order_items:
            flash('Cannot delete product that has been ordered!', 'error')
        else:
            db.session.delete(product)
            db.session.commit()
            flash('Product deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting product: {str(e)}', 'error')
    
    return redirect(url_for('admin_products'))

@app.route('/admin/orders')
def admin_orders():
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    status_filter = request.args.get('status', 'all')
    if status_filter == 'all':
        orders = Order.query.order_by(Order.created_at.desc()).all()
    else:
        orders = Order.query.filter_by(status=status_filter).order_by(Order.created_at.desc()).all()
    
    return render_template('admin/orders.html', orders=orders, status_filter=status_filter, format_currency=format_currency)

@app.route('/admin/update_order_status/<int:order_id>', methods=['POST'])
def admin_update_order_status(order_id):
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    order = Order.query.get_or_404(order_id)
    order.status = request.form['status']
    db.session.commit()
    flash('Order status updated successfully!', 'success')
    return redirect(url_for('admin_orders'))

@app.route('/admin/order_details/<int:order_id>')
def admin_order_details(order_id):
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    order = Order.query.get_or_404(order_id)
    return render_template('admin/order_details.html', order=order, format_currency=format_currency)

@app.route('/admin/users')
def admin_users():
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    users = User.query.all()
    return render_template('admin/users.html', users=users)

@app.route('/admin/user_details/<int:user_id>')
def admin_user_details(user_id):
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    user = User.query.get_or_404(user_id)
    user_orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()
    return render_template('admin/user_details.html', user=user, user_orders=user_orders, format_currency=format_currency)

@app.route('/admin/categories')
def admin_categories():
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    categories = Category.query.all()
    return render_template('admin/categories.html', categories=categories)

@app.route('/admin/add_category', methods=['POST'])
def admin_add_category():
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    try:
        name = request.form['name']
        if Category.query.filter_by(name=name).first():
            flash('Category already exists!', 'error')
        else:
            category = Category(name=name)
            db.session.add(category)
            db.session.commit()
            flash('Category added successfully!', 'success')
    except Exception as e:
        flash(f'Error adding category: {str(e)}', 'error')
    
    return redirect(url_for('admin_categories'))

@app.route('/admin/delete_category/<int:category_id>')
def admin_delete_category(category_id):
    if 'user_id' not in session or session.get('user_email') != 'admin@dropship.com':
        flash('Admin access required!', 'error')
        return redirect(url_for('index'))
    
    category = Category.query.get_or_404(category_id)
    try:
        if category.products:
            flash('Cannot delete category that has products!', 'error')
        else:
            db.session.delete(category)
            db.session.commit()
            flash('Category deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting category: {str(e)}', 'error')
    
    return redirect(url_for('admin_categories'))

# Initialize database and create admin user
def init_db():
    with app.app_context():
        # First, migrate the database if needed
        migrate_database()
        
        # Then create all tables
        db.create_all()
        init_categories()
        init_sample_products()
        
        # Create admin user if not exists
        if not User.query.filter_by(email='admin@dropship.com').first():
            admin_user = User(
                email='admin@dropship.com',
                password=generate_password_hash('admin123'),
                first_name='Admin',
                last_name='User',
                phone='+1234567890'
            )
            db.session.add(admin_user)
            db.session.commit()
            print("✅ Admin user created: admin@dropship.com / admin123")

# This is important for Render deployment
if __name__ == '__main__':
    # Create templates directory if it doesn't exist
    if not os.path.exists('templates'):
        os.makedirs('templates')
        os.makedirs('templates/admin')
        print("✅ Created templates directory structure")
    
    # Delete old database to force recreation
    if os.path.exists('dropship.db'):
        print("🔄 Removing old database to apply new schema...")
        os.remove('dropship.db')
    
    init_db()
    print("=" * 60)
    print("🚀 Premium Dropship E-commerce Application Started!")
    print("=" * 60)
    print("📱 Main Site: http://localhost:5000")
    print("👑 Admin Panel: http://localhost:5000/admin")
    print("🔑 Admin Login: admin@dropship.com / admin123")
    print("=" * 60)
    print("✨ Features: User Registration, Shopping Cart, Orders")
    print("✨ Admin: Product Management, Order Management, Low Stock Alerts")
    print("✨ Mobile: Fully responsive with hamburger menu")
    print("✨ Offers: Strike-through pricing with discount percentages")
    print("✨ Currency: All prices in Indian Rupees (INR)")
    print("=" * 60)
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
